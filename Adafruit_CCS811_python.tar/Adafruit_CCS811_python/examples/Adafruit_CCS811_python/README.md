DEPRECATED LIBRARY Adafruit CCS811 Python
=========================================

This library has been deprecated!

We are now only using our CircuitPython sensor libraries for Python.

We are leaving the code up for historical/research purposes but archiving the repository.

Please use our [Adafruit CircuitPython CSS811](https://github.com/adafruit/Adafruit_CircuitPython_CCS811) library instead!
